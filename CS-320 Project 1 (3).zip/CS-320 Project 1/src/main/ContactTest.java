package main;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class ContactTest {
	protected String contactId, firstNameTest, lastNameTest, phoneNumberTest,
      addressTest;
	protected String tooLongContactId, tooLongFirstName, tooLongLastName,
      tooLongPhoneNumber, tooShortPhoneNumber, tooLongAddress;
	
	  @BeforeEach
	  void setUp() {
	    contactId = "123456789";
	    firstNameTest = "Alexis";
	    lastNameTest = "Wilde";
	    phoneNumberTest = "1111111111";
	    addressTest = "1907 Lake St, Lancaster, OH 43130";
	    tooLongContactId = "12345678912";
	    tooLongFirstName = "SheSellsSeaShellsByTheSeaShore";
	    tooLongLastName = "PeterPiperPickedAPeckOfPickeledPeppers";
	    tooLongPhoneNumber = "123456789123";
	    tooShortPhoneNumber = "123456789";
	    tooLongAddress = "55555555555555 Jake Dr, Ohio, Lancaster Ohio 444555666689";
	  }
	
	 @Test
	  void updateFirstNameTest() {
	    Contact contact = new Contact();
	    Assertions.assertNull(contact.getFirstName());
	    contact.updateFirstName(firstNameTest);
	    Assertions.assertEquals(firstNameTest, contact.getFirstName());
	  }

	  @Test
	  void updateFirstNameTooLongNullTest() {
	    Contact contact = new Contact();
	    Assertions.assertNull(contact.getFirstName());
	    Assertions.assertThrows(IllegalArgumentException.class,
	                            () -> contact.updateFirstName(tooLongFirstName));
	    Assertions.assertNull(contact.getFirstName());
	  }

	  @Test
	  void updateFirstNameTooLongTest() {
	    Contact contact = new Contact(contactId, firstNameTest);
	    Assertions.assertEquals(firstNameTest, contact.getFirstName());
	    Assertions.assertThrows(IllegalArgumentException.class,
	                            () -> contact.updateFirstName(tooLongFirstName));
	    Assertions.assertEquals(firstNameTest, contact.getFirstName());
	  }

	  @Test
	  void updateFirstNameNullTest() {
	    Contact contact = new Contact(contactId, firstNameTest);
	    Assertions.assertEquals(firstNameTest, contact.getFirstName());
	    Assertions.assertThrows(IllegalArgumentException.class,
	                            () -> contact.updateFirstName(null));
	    Assertions.assertEquals(firstNameTest, contact.getFirstName());
	  }

	  @Test
	  void updateLastNameTest() {
	    Contact contact = new Contact();
	    Assertions.assertNull(contact.getLastName());
	    contact.updateLastName(lastNameTest);
	    Assertions.assertEquals(lastNameTest, contact.getLastName());
	  }

	  @Test
	  void updateLastNameTooLongNullTest() {
	    Contact contact = new Contact();
	    Assertions.assertNull(contact.getLastName());
	    Assertions.assertThrows(IllegalArgumentException.class,
	                            () -> contact.updateLastName(tooLongLastName));
	    Assertions.assertNull(contact.getLastName());
	  }

	  @Test
	  void updateLastNameTooLongTest() {
	    Contact contact = new Contact(contactId, firstNameTest, lastNameTest);
	    Assertions.assertEquals(lastNameTest, contact.getLastName());
	    Assertions.assertThrows(IllegalArgumentException.class,
	                            () -> contact.updateLastName(tooLongLastName));
	    Assertions.assertEquals(lastNameTest, contact.getLastName());
	  }

	  @Test
	  void updateLastNameNullTest() {
	    Contact contact = new Contact(contactId, firstNameTest, lastNameTest);
	    Assertions.assertEquals(lastNameTest, contact.getLastName());
	    Assertions.assertThrows(IllegalArgumentException.class,
	                            () -> contact.updateLastName(null));
	    Assertions.assertEquals(lastNameTest, contact.getLastName());
	  }

	  @Test
	  void updatePhoneNumberTooLongTest() {
	    Contact contact =
	        new Contact(contactId, firstNameTest, lastNameTest, phoneNumberTest);
	    Assertions.assertEquals(phoneNumberTest, contact.getPhoneNumber());
	    Assertions.assertThrows(
	        IllegalArgumentException.class,
	        () -> contact.updatePhoneNumber(tooLongPhoneNumber));
	    Assertions.assertEquals(phoneNumberTest, contact.getPhoneNumber());
	  }

	  @Test
	  void updatePhoneNumberTooShortTest() {
	    Contact contact =
	        new Contact(contactId, firstNameTest, lastNameTest, phoneNumberTest);
	    Assertions.assertEquals(phoneNumberTest, contact.getPhoneNumber());
	    Assertions.assertThrows(
	        IllegalArgumentException.class,
	        () -> contact.updatePhoneNumber(tooShortPhoneNumber));
	    Assertions.assertEquals(phoneNumberTest, contact.getPhoneNumber());
	  }

	  @Test
	  void updateAddressTooLongTest() {
	    Contact contact = new Contact(contactId, firstNameTest, lastNameTest,
	                                  phoneNumberTest, addressTest);
	    Assertions.assertEquals(addressTest, contact.getAddress());
	    Assertions.assertThrows(IllegalArgumentException.class,
	                            () -> contact.updateAddress(tooLongAddress));
	    Assertions.assertEquals(addressTest, contact.getAddress());
	  }

}
